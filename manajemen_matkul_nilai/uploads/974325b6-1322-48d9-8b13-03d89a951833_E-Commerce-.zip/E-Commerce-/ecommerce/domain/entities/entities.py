# ecommerce/domain/entities/entities.py
from dataclasses import dataclass

# -------------------
# KATEGORI
# -------------------
@dataclass
class Kategori:
    id: int | None = None
    nama: str | None = None


# -------------------
# PRODUK
# -------------------
@dataclass
class Produk:
    id: int | None = None
    nama: str | None = None
    kategori_id: int | None = None
    lokasi: str | None = None
    keterangan: str | None = None
    harga: float | None = None
    gambar: str | None = None


# -------------------
# KERANJANG
# -------------------
@dataclass
class Keranjang:
    def __init__(self, id, produk_id, jumlah):
        self.id = id
        self.produk_id = produk_id
        self.jumlah = jumlah
        self.produk = None  # diisi di use case

    @property
    def subtotal(self):
        if self.produk:
            return self.produk.harga * self.jumlah
        return 0

