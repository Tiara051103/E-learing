# ecommerce/domain/repositories/repositories.py
from ecommerce.infrastructure.sqlite_db.db_settings import get_connection
from ecommerce.domain.entities.entities import Kategori, Produk, Keranjang
from ecommerce.infrastructure.sqlite_db.mappers import (
    map_row_to_kategori,
    map_row_to_produk,
    map_row_to_keranjang
)

# ======================
# KATEGORI REPOSITORY
# ======================
class KategoriRepository:
    def get_all(self):
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM kategori ORDER BY nama"
        ).fetchall()
        conn.close()
        return [map_row_to_kategori(r) for r in rows]

    def add(self, nama):
        conn = get_connection()
        conn.execute(
            "INSERT INTO kategori (nama) VALUES (?)",
            (nama,)
        )
        conn.commit()
        conn.close()

    def delete(self, id):
        conn = get_connection()
        conn.execute(
            "DELETE FROM kategori WHERE id=?",
            (id,)
        )
        conn.commit()
        conn.close()


# ======================
# PRODUK REPOSITORY
# ======================
class ProdukRepository:
    def get_all(self):
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM produk ORDER BY id DESC"
        ).fetchall()
        conn.close()
        return [map_row_to_produk(r) for r in rows]

    def get_by_kategori(self, kategori_id):
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM produk WHERE kategori_id=?",
            (kategori_id,)
        ).fetchall()
        conn.close()
        return [map_row_to_produk(r) for r in rows]

    def get_by_id(self, produk_id):
        conn = get_connection()
        row = conn.execute(
            "SELECT * FROM produk WHERE id=?",
            (produk_id,)
        ).fetchone()
        conn.close()
        return map_row_to_produk(row) if row else None

    def add(self, nama, kategori_id, lokasi, keterangan, harga, gambar):
        conn = get_connection()
        conn.execute("""
            INSERT INTO produk (nama, kategori_id, lokasi, keterangan, harga, gambar)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (nama, kategori_id, lokasi, keterangan, harga, gambar))
        conn.commit()
        conn.close()

    def update(self, id, nama, kategori_id, lokasi, keterangan, harga, gambar):
        conn = get_connection()
        conn.execute("""
            UPDATE produk
            SET nama=?, kategori_id=?, lokasi=?, keterangan=?, harga=?, gambar=?
            WHERE id=?
        """, (nama, kategori_id, lokasi, keterangan, harga, gambar, id))
        conn.commit()
        conn.close()

    def delete(self, id):
        conn = get_connection()
        conn.execute(
            "DELETE FROM produk WHERE id=?",
            (id,)
        )
        conn.commit()
        conn.close()

    # 🔥 FILTER + SEARCH (FINAL)
    def filter(self, kategori_id=None, keyword=None,
               lokasi=None, min_harga=None, max_harga=None):

        conn = get_connection()

        query = "SELECT * FROM produk WHERE 1=1"
        params = []

        if kategori_id is not None:
            query += " AND kategori_id = ?"
            params.append(kategori_id)

        if keyword:
            query += " AND nama LIKE ?"
            params.append(f"%{keyword}%")

        if lokasi:
            query += " AND lokasi LIKE ?"
            params.append(f"%{lokasi}%")

        if min_harga is not None:
            query += " AND harga >= ?"
            params.append(min_harga)

        if max_harga is not None:
            query += " AND harga <= ?"
            params.append(max_harga)

        query += " ORDER BY id DESC"

        rows = conn.execute(query, params).fetchall()
        conn.close()

        return [map_row_to_produk(r) for r in rows]


# ======================
# KERANJANG REPOSITORY
# ======================
class KeranjangRepository:
    def get_all(self):
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM keranjang"
        ).fetchall()
        conn.close()
        return [map_row_to_keranjang(r) for r in rows]

    def get_by_produk(self, produk_id):
        conn = get_connection()
        row = conn.execute(
            "SELECT * FROM keranjang WHERE produk_id=?",
            (produk_id,)
        ).fetchone()
        conn.close()
        return map_row_to_keranjang(row) if row else None

    def add(self, produk_id, jumlah):
        conn = get_connection()
        conn.execute(
            "INSERT INTO keranjang (produk_id, jumlah) VALUES (?, ?)",
            (produk_id, jumlah)
        )
        conn.commit()
        conn.close()

    def update_jumlah(self, id, jumlah):
        conn = get_connection()
        conn.execute(
            "UPDATE keranjang SET jumlah=? WHERE id=?",
            (jumlah, id)
        )
        conn.commit()
        conn.close()

    def delete(self, id):
        conn = get_connection()
        conn.execute(
            "DELETE FROM keranjang WHERE id=?",
            (id,)
        )
        conn.commit()
        conn.close()

    def delete_all(self):
        conn = get_connection()
        conn.execute("DELETE FROM keranjang")
        conn.commit()
        conn.close()
