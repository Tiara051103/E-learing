# ecommerce/application/use_cases.py
from ecommerce.domain.repositories.repositories import (
    KategoriRepository,
    ProdukRepository,
    KeranjangRepository
)

# -------------------
# KATEGORI USE CASE
# -------------------
class KategoriUseCase:
    def __init__(self):
        self.repo = KategoriRepository()

    def list_kategori(self):
        return self.repo.get_all()

    def tambah_kategori(self, nama):
        self.repo.add(nama)

    def hapus_kategori(self, kategori_id):
        self.repo.delete(kategori_id)


# -------------------
# PRODUK USE CASE
# -------------------
class ProdukUseCase:
    def __init__(self):
        self.repo = ProdukRepository()

    def list_produk(self):
        return self.repo.get_all()

    def list_produk_by_kategori(self, kategori_id):
        return self.repo.get_by_kategori(kategori_id)

    def tambah_produk(self, nama, kategori_id, lokasi, keterangan, harga, gambar):
        self.repo.add(nama, kategori_id, lokasi, keterangan, harga, gambar)

    def edit_produk(self, produk_id, nama, kategori_id, lokasi, keterangan, harga, gambar):
        self.repo.update(produk_id, nama, kategori_id, lokasi, keterangan, harga, gambar)

    def hapus_produk(self, produk_id):
        self.repo.delete(produk_id)

    def get_produk_detail(self, produk_id):
        return self.repo.get_by_id(produk_id)
    
    # ✅ FILTER KOMBINASI
    def filter_produk(self, kategori_id=None, keyword=None,lokasi=None, min_harga=None, max_harga=None):
        return self.repo.filter(
        kategori_id=kategori_id,
        keyword=keyword,
        lokasi=lokasi,
        min_harga=min_harga,
        max_harga=max_harga
    )

# -------------------
# KERANJANG USE CASE
# -------------------
class KeranjangUseCase:
    def __init__(self):
        self.repo = KeranjangRepository()
        self.produk_repo = ProdukRepository()

    def list_keranjang(self):
        keranjang_list = self.repo.get_all()
        # Lengkapi objek Produk agar subtotal bisa dihitung
        for item in keranjang_list:
            produk = self.produk_repo.get_by_id(item.produk_id)
            item.produk = produk
        return keranjang_list

    def tambah_ke_keranjang(self, produk_id, jumlah=1):
        item = self.repo.get_by_produk(produk_id)

        # kalau produk sudah ada → tambah jumlah
        if item:
            self.repo.update_jumlah(item.id, item.jumlah + jumlah)
        else:
            self.repo.add(produk_id, jumlah)

    def hapus_dari_keranjang(self, keranjang_id):
        self.repo.delete(keranjang_id)

    def kosongkan_keranjang(self):
        self.repo.delete_all()

    def total_keranjang(self):
        """Menghitung total semua subtotal di keranjang"""
        keranjang_list = self.list_keranjang()
        return sum(item.subtotal for item in keranjang_list)
