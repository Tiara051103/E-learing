-- sqlite3

CREATE TABLE users (
    id TEXT PRIMARY KEY,
    username TEXT,
    password TEXT,
    status TEXT
);
