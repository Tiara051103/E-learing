# flask_app/routes/routes.py
from flask import Blueprint, render_template, request, redirect, url_for
from ecommerce.application.use_cases import KategoriUseCase, ProdukUseCase, KeranjangUseCase

main_bp = Blueprint("main", __name__)

kategori_uc = KategoriUseCase()
produk_uc = ProdukUseCase()
keranjang_uc = KeranjangUseCase()

# -------------------------
# HOME / PRODUK LIST
# -------------------------
@main_bp.route("/")
def home():
    kategori_id = request.args.get("kategori", type=int)
    keyword = request.args.get("keyword")
    lokasi = request.args.get("lokasi")
    min_harga = request.args.get("min_harga", type=int)
    max_harga = request.args.get("max_harga", type=int)

    produk_list = produk_uc.filter_produk(
        kategori_id=kategori_id,
        keyword=keyword,
        lokasi=lokasi,
        min_harga=min_harga,
        max_harga=max_harga
    )

    kategori_list = kategori_uc.list_kategori()

    return render_template(
        "pages/home.html",
        produk_list=produk_list,
        kategori_list=kategori_list
    )


# -------------------------
# FILTER PRODUK BY KATEGORI
# -------------------------
@main_bp.route("/kategori/<int:kategori_id>")
def produk_by_kategori(kategori_id):
    produk_list = produk_uc.list_produk_by_kategori(kategori_id)
    kategori_list = kategori_uc.list_kategori()
    return render_template("pages/home.html", produk_list=produk_list, kategori_list=kategori_list, selected_kategori=kategori_id)

# -------------------------
# TAMBAH PRODUK KE KERANJANG
# -------------------------
@main_bp.route("/keranjang/tambah/<int:produk_id>", methods=["POST"])
def tambah_ke_keranjang(produk_id):
    jumlah = int(request.form.get("jumlah", 1))
    keranjang_uc.tambah_ke_keranjang(produk_id, jumlah)
    return redirect(url_for("main.view_keranjang"))

# -------------------------
# LIHAT KERANJANG
# -------------------------
@main_bp.route("/keranjang")
def view_keranjang():
    keranjang_list = keranjang_uc.list_keranjang()
    total = keranjang_uc.total_keranjang()
    return render_template("pages/keranjang.html", keranjang_list=keranjang_list, total=total)

# -------------------------
# HAPUS ITEM DARI KERANJANG
# -------------------------
@main_bp.route("/keranjang/hapus/<int:keranjang_id>")
def hapus_dari_keranjang(keranjang_id):
    keranjang_uc.hapus_dari_keranjang(keranjang_id)
    return redirect(url_for("main.view_keranjang"))

# -------------------------
# KOSONGKAN KERANJANG
# -------------------------
@main_bp.route("/keranjang/kosongkan")
def kosongkan_keranjang():
    keranjang_uc.kosongkan_keranjang()
    return redirect(url_for("main.view_keranjang"))

@main_bp.route("/produk/tambah", methods=["POST"])
def tambah_produk():
    produk_uc.tambah_produk(
        nama=request.form["nama"],
        kategori_id=int(request.form["kategori_id"]),
        lokasi=request.form["lokasi"],
        keterangan=request.form.get("keterangan"),
        harga=int(request.form["harga"]),
        gambar=None
    )
    return redirect(url_for("main.home"))
# -------------------------
# DETAIL PRODUK
# -------------------------
@main_bp.route("/produk/<int:produk_id>")
def produk_detail(produk_id):
    produk = produk_uc.get_produk_detail(produk_id)
    if not produk:
        return "Produk tidak ditemukan", 404
    return render_template("pages/produk_detail.html", produk=produk)

# -------------------------
# HAPUS PRODUK
# -------------------------
@main_bp.route("/produk/hapus/<int:produk_id>", methods=["POST"])
def hapus_produk(produk_id):
    produk_uc.hapus_produk(produk_id)
    return redirect(url_for("main.home"))

# -------------------------
# CHECKOUT
# -------------------------
@main_bp.route("/checkout")
def checkout():
    keranjang_list = keranjang_uc.list_keranjang()
    total = keranjang_uc.total_keranjang()

    # versi sederhana → langsung kosongkan
    keranjang_uc.kosongkan_keranjang()

    return render_template(
        "pages/checkout.html",
        keranjang_list=keranjang_list,
        total=total
    )
