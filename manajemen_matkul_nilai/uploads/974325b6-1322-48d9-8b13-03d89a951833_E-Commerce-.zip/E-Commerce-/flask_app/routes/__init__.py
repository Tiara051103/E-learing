from .routes import main_bp
from .auth_routes import auth_bp

__all__ = ["main_bp", "auth_bp"]
