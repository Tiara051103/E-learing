from auth.domain.entities import User
from auth.domain.repositories import DosenRepository
import sqlite3

class DosenRepoSQLite(DosenRepository):
    def __init__(self):
        self.conn = sqlite3.connect('db.sqlite')
        self.cursor = self.conn.cursor()

    def get_all(self):
        return self.cursor.execute("SELECT * FROM dosen").fetchall()

    def get_by_id(self, id):
        return self.cursor.execute("SELECT * FROM dosen WHERE id=?", (id,)).fetchone()

    def create(self, data):
        self.cursor.execute(
            "INSERT INTO dosen (nama, nidn) VALUES (?, ?)",
            (data['nama'], data['nidn'])
        )
        self.conn.commit()

    def update(self, id, data):
        self.cursor.execute(
            "UPDATE dosen SET nama=?, nidn=? WHERE id=?",
            (data['nama'], data['nidn'], id)
        )
        self.conn.commit()

    def delete(self, id):
        self.cursor.execute("DELETE FROM dosen WHERE id=?", (id,))
        self.conn.commit()
