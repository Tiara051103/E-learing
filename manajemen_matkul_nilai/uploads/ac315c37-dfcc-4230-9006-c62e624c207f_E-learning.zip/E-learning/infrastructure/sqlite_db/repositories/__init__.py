from .repositories import DosenRepository

__all__ = ["DosenRepository"]