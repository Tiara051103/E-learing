from domain.entities import Dosen, Matakuliah, Enrollment
from domain.repositories import DosenRepository, MatakuliahRepository, EnrollmentRepository
from domain.services import IdGeneratorService
from application.result import Result


# ==========================
#      USE CASE: DOSEN
# ==========================
class TambahDosenUseCase:
    def __init__(self, repo: DosenRepository, id_service: IdGeneratorService):
        self.repo = repo
        self.id_service = id_service

    def execute(self, nama: str, nidn: str) -> Result:
        id = self.id_service.generate_id()
        dosen = Dosen(id=id, nama=nama, nidn=nidn)
        self.repo.add(dosen)
        return Result.ok()


class UpdateDosenUseCase:
    def __init__(self, repo: DosenRepository):
        self.repo = repo

    def execute(self, id: str, nama: str, nidn: str) -> Result:
        dosen = Dosen(id=id, nama=nama, nidn=nidn)
        self.repo.update(dosen)
        return Result.ok()


class DeleteDosenUseCase:
    def __init__(self, repo: DosenRepository):
        self.repo = repo

    def execute(self, id: str) -> Result:
        self.repo.delete_by_id(id)
        return Result.ok()


class DaftarDosenUseCase:
    def __init__(self, repo: DosenRepository):
        self.repo = repo

    def execute(self) -> Result:
        data = self.repo.get_all()
        return Result.ok(data)



# ==========================
#   USE CASE: MATAKULIAH
# ==========================
class TambahMatakuliahUseCase:
    def __init__(self, repo: MatakuliahRepository, id_service: IdGeneratorService):
        self.repo = repo
        self.id_service = id_service

    def execute(self, nama: str, id_dosen: str) -> Result:
        id = self.id_service.generate_id()
        mk = Matakuliah(id=id, nama=nama, id_dosen=id_dosen)
        self.repo.add(mk)
        return Result.ok()


class UpdateMatakuliahUseCase:
    def __init__(self, repo: MatakuliahRepository):
        self.repo = repo

    def execute(self, id: str, nama: str, id_dosen: str) -> Result:
        mk = Matakuliah(id=id, nama=nama, id_dosen=id_dosen)
        self.repo.update(mk)
        return Result.ok()


class DeleteMatakuliahUseCase:
    def __init__(self, repo: MatakuliahRepository):
        self.repo = repo

    def execute(self, id: str) -> Result:
        self.repo.delete_by_id(id)
        return Result.ok()


class DaftarMatakuliahUseCase:
    def __init__(self, repo: MatakuliahRepository):
        self.repo = repo

    def execute(self) -> Result:
        data = self.repo.get_all()
        return Result.ok(data)



# ==========================
#    USE CASE: ENROLLMENT
# ==========================
class TambahEnrollmentUseCase:
    def __init__(self, repo: EnrollmentRepository, id_service: IdGeneratorService):
        self.repo = repo
        self.id_service = id_service

    def execute(self, nama_kelas: str, id_matakuliah: str) -> Result:
        id = self.id_service.generate_id()
        kelas = Enrollment(id=id, nama_kelas=nama_kelas, id_matakuliah=id_matakuliah)
        self.repo.add(kelas)
        return Result.ok()


class UpdateEnrollmentUseCase:
    def __init__(self, repo: EnrollmentRepository):
        self.repo = repo

    def execute(self, id: str, nama_kelas: str, id_matakuliah: str) -> Result:
        kelas = Enrollment(id=id, nama_kelas=nama_kelas, id_matakuliah=id_matakuliah)
        self.repo.update(kelas)
        return Result.ok()


class DeleteEnrollmentUseCase:
    def __init__(self, repo: EnrollmentRepository):
        self.repo = repo

    def execute(self, id: str) -> Result:
        self.repo.delete_by_id(id)
        return Result.ok()


class DaftarEnrollmentUseCase:
    def __init__(self, repo: EnrollmentRepository):
        self.repo = repo

    def execute(self) -> Result:
        data = self.repo.get_all()
        return Result.ok(data)
