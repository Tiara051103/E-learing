from abc import ABC, abstractmethod
from domain.entities import Dosen, Matakuliah, Enrollment

class BaseRepository(ABC):
    @abstractmethod
    def add(self, entity): pass

    @abstractmethod
    def update(self, entity): pass

    @abstractmethod
    def delete_by_id(self, id: str): pass

    @abstractmethod
    def get_all(self): pass

    @abstractmethod
    def get_by_id(self, id: str): pass


class DosenRepository(BaseRepository):
    @abstractmethod
    def get_by_nama(self, nama: str) -> Dosen | None:
        pass


class MatakuliahRepository(BaseRepository):
    @abstractmethod
    def get_by_dosen(self, id_dosen: str) -> list[Matakuliah]:
        pass


class EnrollmentRepository(BaseRepository):
    @abstractmethod
    def get_by_matakuliah(self, id_matakuliah: str) -> list[Enrollment]:
        pass
