from .repositories import Matakuliah, Dosen, EnrollmentRepository

__all__ = ["Matakuliah","Dosen", "EnrollmentRepository"]