from dataclasses import dataclass

@dataclass
class Dosen:
    id: str
    nama: str
    nidn: str


@dataclass
class Matakuliah:
    id: str
    nama: str
    id_dosen: str   # relasi ke Dosen


@dataclass
class Enrollment:
    id: str
    nama_kelas: str
    id_matakuliah: str  # relasi ke Matakuliah
